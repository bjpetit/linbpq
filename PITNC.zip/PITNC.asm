;**********************************************************
;*  newtnc.HEX
;**********************************************************
;*  This file had been disassembled using unPIC.pl
;*  
;*  unPIC.pl is written by Tamas Rudnai
;*   -> based on Timo Rossi's work on pic14dis.c
;**********************************************************
;*  Please advised that unPIC.pl is not foolproof.
;*  It could happen that the code was not correctly
;*  reversed as the chip is not defined corretly
;*  or because of a bug in the tool's code.
;**********************************************************

; Disassembled from original TNC-X source, downloaded July 2012
; Modified for BPQKISS July 2012

; Then Modified for I2C comms with Raspberry PI and a 16F1847 Processor

       list p=16F1847

        include "P16F1847.INC"  

	radix	DEC
	
#define MYBOARD 1		; Custom PI board - not hacked TNC-X

; Original TNC-X, using 16F628A
 
#define clockbit 0		; clock on fram A0
;#define A1   41		; TXDelay pot A
#define databit  2		; data on fram
#define csbit 3			; chip select on fram

#define DCDLED PORTA, 4 ;		//DCD LED A4

#ifdef	MYBOARD

#define m1 PORTA, 7		; Modem Control 1 B7
#define m0 PORTB, 0		; Same as PTT

;	TXD is B5, RXD B2 (alt assignmemts)

#else

; Hacked TNC-X

#define m0 PORTB, 7		;//modem control line B7
#define m1 PORTA, 5		; Modem Control 1 A5

#endif


#define PTT   PORTB, 0 	;//radio PTT 0 B0
#define radtx PORTB, 3	;//radio transmit data B3
#define radrx PORTB, 6	;//radio receive data B6

#define radrxbit 0x40


; The 16F88 has TXD on RB5, RXD on RB2, SCL on RB4 and SDA on RB1
; We dont use term1/term2 (baud rate fixed at 19200), so can use them for m0/m1
;
; The 16F1847 can be the same, if alt RX and TX are selected

;#define m1   PORTA, 5		;//modem control line A5

#define BIT0 1
#define BIT1 2
#define BIT2 4
#define BIT3 8
#define BIT4 0x10
#define BIT5 0x20
#define BIT6 0x40
#define BIT7 0x80

	__config  _CONFIG1, _BOREN_OFF & _CP_OFF & _FOSC_HS & _LVP_OFF & _MCLRE_OFF & _WDTE_ON & _PWRTE_ON
	__config  _CONFIG2, _WRT_OFF & _PLLEN_OFF & _LVP_OFF
	
	
; Boolean flags. Using bits saves lots of space and allows use of bit set/clear/test and skip instructions

#define oldstate boolflags, 0
#define fiveones boolflags, 1
#define done boolflags, 2
#define isflag boolflags, 3
#define rmiddle boolflags, 4
#define xmiddle boolflags, 5
#define flag boolflags, 6
#define crcflag boolflags, 7

#define DB txflags, 0
#define firstpac txflags, 1
#define DoingCSMA txflags, 2
#define	InFESC txflags,3			; FESC received
#define	SendNACK txflags, 4			; Last packet from i2c had bad crc
#define sendparms txflags, 5		; Send NVRAM Parms as a KISS frame when RX is idle
#define rebootFlag txflags, 6		; Set to cause a reset
#define	CarrierFlag txflags,7		; Send Carrier for 10 secs


#define CheckCtrl bpqflags, 3		; seen FEND, next byte is control
#define GetCmdParam bpqflags, 6		; Seen KISS Command, next byte is param
#define FrameNeedsACK bpqflags, 7 	; Send ACK when TX is over

#define PollMode kissflags, 0		; In Polled KISS Mode
#define Polled kissflags, 1			; Poll Received
#define Discard kissflags, 2		; not for us, so discard till FEND seen
#define SendACK kissflags, 4		; Send ACK Byte to host
#define SendFEND kissflags, 5		; Send FEND to host
#define HOSTCRC kissflags, 6		; using CRC on host side
#define i2cmode kissflags, 7		; set if using i2cinterface (otherwise use KISS


; KISS Control

#define FEND 0xC0
#define FESC 0xDB
#define TFEND 0xDC
#define TFESC 0xDD

; BPQKISS Control Bytes

#define ACK	 0x0c
#define POLL 0x0e
#define NACK 0x15

ASYTX	MACRO
	MYBANKSEL TXREG
	movwf	TXREG
	MYBANKSEL	STATUS
		ENDM
		
MYBANKSEL	MACRO LEVEL

	if	LEVEL == STATUS
	errorlevel +302 
	else
	errorlevel -302
	endif
	BANKSEL LEVEL
	ENDM
		
	org  0xf000

;	The absolue address f000h is mapped to the 0000 location of EE data memory
	
;	If param order follows KISS command values, updating is easier

;0x01	TX DELAY
;0x02	Persistence
;0x03	SlotTime
;0x04	TXtail
;0x05	FullDuplex
;0x06	Our Channel / Poll Mode bits
;0x07	Set I2C Address
;0x08	Read Params
;0x09	Reset

p0	de	0		; Unused
p1	de	40		; TXdelay - Zero means use ADC
p3	de	64		; Persistance
p2	de	10		; Slottime x 10 mS
p4	de	0		; TXTail
p5	de	0		; Full Duplex
p6	de	0		; Our Channel - not needed for i2c, but could be if we allow multidrop kiss on async port
P7	de	0		; I2C Address (As seen from Linux - is shifted up one bit) Zero means use async port (at 19200)


#define	TXDELAY		1
#define PERSIST		2
#define SLOTTIME	3
#define TXTAIL		4	
#define FULLDUP		5	; Not used here
#define	KISSCHANNEL	6
#define I2CADDRESS	7

Rst_Vector  org 0x000

	goto	main
	    
Int_Vector	org 4

;	Status saved by hardware
        
;	Only int_rtcc uses other regs, so just save in that routine
                
;	See what interrupted  

   	MYBANKSEL STATUS
   	
	btfsc	PIR1,SSP1IF 			; Is this a SSP interrupt?
	goto	SSP_Handler 			; Yes, service SSP interrupt.

	btfss	INTCON, TMR0IE
	goto	loop_020
	
	btfsc           INTCON, TMR0IF; 001E: 190B
	goto            INT_RTCC    ; 001F: 2880

loop_020
; jump here from: 001D
        btfss           INTCON, IOCIE; 0020: 1D8B
        goto            loop_024    ; 0021: 2824

        btfsc           INTCON, IOCIF; 0022: 180B
        goto            int_rb    ; 0023: 283D

loop_024
; jump here from: 0021

        movlw           PIE1      ; I guess it does this to avoid a bank switch, but is probably slower
        movwf           FSR0         ; 0025: 0084
        btfss           INDF0, TMR2IE     ; 0026: 1C80
		retfie
		
        btfsc           PIR1, TMR2IF; 0028: 188C
        goto            INT_TIMER2    ; 0029: 2A1E

        retfie                      ; 003C: 0009
;
; end of label_000
;------------------------------------------------------------


int_rb
; jump here from: 0023
;  if (input(radrx) != oldstate){	   //double check just to make sure the pin has really changed
;  disable_interrupts(INT_RB);	   //no more change on B interrupts until the next bit period
;  set_rtcc(240);			       //13 ticks (416 us) to next bit reading
;  bit_clear(intcon,2);		       //don't let it cause an interrupt immediately
;  }

;	Doesn't use any registers
   
		movlw	0x00
        btfsc	radrx
        movlw	0x01			; oldstate is boolflags, 0
        
	    xorwf	boolflags, W	; Bit zero of WREG set if bits are different
        btfss   WREG, 0
        goto	nochange
;
;	Bit changed, reprime rtcc for next interval (416 us)

        bcf		INTCON, IOCIE; Turn off Pin change interrupt
         
        movlw	0xf0        ; 0048: 30F0
        movwf	TMR0        ; Bank 0
        
        bcf		INTCON, TMR0IF; 004A: 110B

nochange

;	Can't clear IOCIF directly - clear active bits in IOCBF

		MYBANKSEL IOCBF
		bcf		IOCBF, 6	; radrx bit is the only one enabled
		retfie

;------------------------------------------------------------
; Subroutine: fram_bits
;
; called from: 006F
; called from: 0074
; called from: 0077
; called from: 007A
; called from: 007D
; called from: 029F
; called from: 02A8
; called from: 02B1

;   mask =0b10000000;   			       //start with MSB
;   for(bittc=0;bittc<8;bittc++){
;      output_low(data);
;      if ((mask & obt) != 0) (output_high(data));
;      output_high(clock);
;      output_low(clock);
;      rotate_right(&mask,1);
;   }


fram_bits
        movlw           0x80        ; 004E: 3080
        movwf           mem_6a      ; 004F: 00EA
        clrf            mem_69   ; 0050: 01E9

label_051
; jump here from: 0060
        movf            mem_69, W   ; 0051: 0869
        sublw           0x07        ; 0052: 3C07
        btfss           STATUS, C   ; 0053: 1C03
        goto            loop_061    ; 0054: 2861

        bcf             PORTA, databit    ; 0055: 1105
        movf            mem_6a, W   ; 0056: 086A
        andwf           mem_68, W   ; 0057: 0568
        xorlw           0x00        ; 0058: 3A00
        btfss           STATUS, Z   ; 0059: 1D03
        bsf             PORTA, databit    ; 005A: 1505
        bsf             PORTA, clockbit    ; 005B: 1405
        bcf             PORTA, clockbit    ; 005C: 1005
        rrf             mem_6a, W   ; 005D: 0C6A
        rrf             mem_6a, f   ; 005E: 0CEA
        incf            mem_69, f   ; 005F: 0AE9
        goto            label_051   ; 0060: 2851

loop_061
; jump here from: 0054
        retlw           0x00        ; 0061: 3400
;
; end of label_000
;------------------------------------------------------------

INT_RTCC
; jump here from: 001F

		incf	FrameBits, f
        
;    set_rtcc(224);				           //reset the clock
;    bit_clear(intcon,2);			       //don't let it generate an immediate interrupt

        movlw           0xe0        ; 0080: 30E0
        movwf           TMR0        ; 0081: 0081
        
		bcf		INTCON, TMR0IF		; Clear int occured flag
           
; if (ones == 7){
;	     done = true;				       //seven ones -- noise from the MX-614... time to start over
;	     rcvinadd = begin - 2;			   //go back to before the "noise" data
;	     if (rcvinadd == -2) rcvinadd = 2046;
;	     if (rcvinadd == -1) rcvinadd = 2047;
;    	     return;				           //we're done receiving, so leave
;    }        

        movf            ones, W   ; 0083: 0830
        sublw           0x07        ; 0084: 3C07
        btfss           STATUS, Z   ; 0085: 1D03
        goto            NotAbort    ; 0086: 28A4
        
;	Abort
		
		clrf	FrameBits
        bsf             done   ; 0087: 152F

;	Reset pointers

		movf	beginHi, W
        movwf	rcvinaddHi
 
		movf	beginLo, W
        movwf	rcvinaddLo
        
        retfie

NotAbort

;	Save regs we might use

        movf            mem_77, W   ; 0010: 0877
        movwf           mem_23      ; 0011: 00A3
        movf            mem_78, W   ; 0012: 0878
        movwf           mem_24      ; 0013: 00A4
        movf            mem_79, W   ; 0014: 0879
        movwf           mem_25      ; 0015: 00A5
        movf            mem_7a, W   ; 0016: 087A
        movwf           mem_26      ; 0017: 00A6
        movf            mem_7b, W   ; 0018: 087B
        movwf           mem_27      ; 0019: 00A7

        btfsc           fiveones   ; 00A4: 18AF
        goto            loop_0c8    ; 00A5: 28C8

;	Not 5 ones, just save new bit

        movlw	0x01
        movwf	rbit		; assume 1, unless a change
        incf	ones, f
        
        movlw	0x00
        btfsc	radrx
        movlw	0x01		; W = state of radrx (bit 0 of boolflags)
           
        xorwf	boolflags, W	; Bottom bit of W is set if changed
        btfss	WREG, 0
        goto nochange2
        
;	Bit changed, so a zero
 
        clrf	ones
        clrf	rbit
        
		movlw	0x01
        xorwf	boolflags, f	; Toggle oldstate

nochange2

;	Shift in new bit (from Carry)

        bsf             STATUS, C	; assume 1
		btfss	rbit,0
        bcf             STATUS, C   ; no, it's a zero
        rrf             rcvbyte, f   ; 00C6: 0CAD
        
        incf            bitcount, f   ; 00C7: 0AAE

loop_0c8
; jump here from: 00A5
        btfss           fiveones   ; 00C8: 1CAF
        goto            loop_0e5    ; 00C9: 28E5

;	5 ones received - if next bit is a zero, ignore it (stuffed bit)

        bcf             fiveones   ; 00CA: 10AF
        movlw           0x00        ; 00CB: 3000
        btfsc           radrx    ; 00CC: 1B06
        movlw           0x01        ; 00CD: 3001
        movwf           mem_61      ; 00CE: 00E1
        movlw           0x00        ; 00CF: 3000
        btfsc           oldstate   ; 00D0: 182F
        movlw           0x01        ; 00D1: 3001
        subwf           mem_61, W   ; 00D2: 0261
        btfsc           STATUS, Z   ; 00D3: 1903
        goto            loop_0e0    ; 00D4: 28E0

        clrf            ones   ; 00D5: 01B0
        movlw           0x00        ; 00D6: 3000
        btfss           oldstate   ; 00D7: 1C2F
        movlw           0x01        ; 00D8: 3001
        movwf           mem_78      ; 00D9: 00F8
        btfsc           mem_78, 0   ; 00DA: 1878
        goto            loop_0de    ; 00DB: 28DE

        bcf             oldstate   ; 00DC: 102F
        goto            label_0df   ; 00DD: 28DF

loop_0de
; jump here from: 00DB
        bsf             oldstate   ; 00DE: 142F

label_0df
; jump here from: 00DD
        goto            loop_0e5    ; 00DF: 28E5

loop_0e0
; jump here from: 00D4

        incf            ones, f   ; 00E0: 0AB0
        bsf             STATUS, C   ; 00E1: 1403
        rrf             rcvbyte, f   ; 00E2: 0CAD
        incf            bitcount, f   ; 00E3: 0AAE
        bsf             isflag   ; 00E4: 15AF

loop_0e5
; jump here from: 00C9
; jump here from: 00DF
        movf            ones, W   ; 00E5: 0830
        sublw           0x05        ; 00E6: 3C05
        btfsc           STATUS, Z   ; 00E7: 1903
        bsf             fiveones   ; 00E8: 14AF
        movf            bitcount, W   ; 00E9: 082E
        sublw           0x08        ; 00EA: 3C08
        btfss           STATUS, Z   ; 00EB: 1D03
        goto            loop_21a    ; 00EC: 2A1A
        
        ; bitcount = 8

        movf            count, W   ; 00ED: 0833
        sublw           0x0c        ; 00EE: 3C0C
        btfsc           STATUS, C   ; 00EF: 1803
        incf            count, f   ; 00F0: 0AB3
        movf            rcvbyte, W   ; 00F1: 082D
        sublw           0x7e        ; 00F2: 3C7E
        btfss           STATUS, Z   ; 00F3: 1D03
        goto            loop_0f9    ; 00F4: 28F9

        movf            count, W   ; 00F5: 0833
        sublw           0x02        ; 00F6: 3C02
        btfsc           STATUS, C   ; 00F7: 1803
        clrf            count   ; 00F8: 01B3

loop_0f9
; jump here from: 00F4
        movf            rcvbyte, W   ; 00F9: 082D
        sublw           0x7e        ; 00FA: 3C7E
        btfss           STATUS, Z   ; 00FB: 1D03
        goto            loop_166    ; 00FC: 2966

        btfss           isflag   ; 00FD: 1DAF
        goto            loop_166    ; 00FE: 2966

        movf            count, W   ; 00FF: 0833
        sublw           0x0b        ; 0100: 3C0B
        btfsc           STATUS, C   ; 0101: 1803
        goto            loop_166    ; 0102: 2966
        
        ; check CRC

        movlw           0xff        ; 0103: 30FF
        xorwf           crc_hi, f   ; 0104: 06B2
        xorwf           crc_lo, f   ; 0105: 06B1
        movf            minus2, W   ; 0106: 082C
        subwf           crc_lo, W   ; 0107: 0231
        btfss           STATUS, Z   ; 0108: 1D03
        goto            loop_10e    ; 0109: 290E

        movf            minus1, W   ; 010A: 082B
        subwf           crc_hi, W   ; 010B: 0232
        btfsc           STATUS, Z   ; 010C: 1903
        goto            loop_113    ; 010D: 2913

loop_10e
; jump here from: 0109

        movf            beginHi, W   ; 010E: 083B
        movwf           rcvinaddHi      ; 010F: 00B7
        movf            beginLo, W   ; 0110: 083A
        movwf           rcvinaddLo      ; 0111: 00B6
        
        goto            setupframe   ; 0112: 2962

loop_113
; jump here from: 010D

;	Good frame. Write Checkum, FEND to terminate, then FEND CTRL to start new one

        incf            receivedpackets, f   ; 0113: 0AB4

; Send the checksum before the FEND

; Checksum in theory includes the FENDs, but the two cancel out, so it is quicker to include neither

	btfss	HOSTCRC		;using CRC?
	goto	NotUsingCRC2


		movf	TXCRC, w

;	If FEND or ESFC, escape it

		xorlw	0xc0        ; I didn;'t think of this
		btfsc	STATUS, Z   ; 0172: 1903
		goto	crcisfend    

		xorlw	0x1b        ; Actually checking DB
		btfsc	STATUS, Z
		goto	crcisfesc

		movf	TXCRC, W
		goto	write_to_host
		
crcisfend

		movlw	0xdb
		call	write_to_tnctohost_fram
		movlw	0xdc
		goto	write_to_host
		
crcisfesc

		movlw	0xdb
		call	write_to_tnctohost_fram
		movlw	0xdd
		
write_to_host

		call	write_to_tnctohost_fram
		
NotUsingCRC2:
	
		movlw	FEND			; Closing FEND
		call	write_to_tnctohost_fram
		
;	Save start of frame (in case frame is duff)
	
        movf            rcvinaddHi, W   ; 015E: 0837
        movwf           beginHi      ; 015F: 00BB
        movf            rcvinaddLo, W   ; 0160: 0836
        movwf           beginLo      ; 0161: 00BA

setupframe:

;	Next frame may start immediatly (shared FLAG), so set upp as if findflag has just been done

;	Write FEND and control byte to buffer
        
        movlw	0xc0        ; 04F8: 30C0
 		call	write_to_tnctohost_fram

;	writing the control byte - add in address bits
        
        movf	OurChannel, W
        movwf	TXCRC				; initialise checksum
        
 		call	write_to_tnctohost_fram

        movlw           0xff        ; 0162: 30FF
        movwf           crc_lo      ; 0163: 00B1
        movwf           crc_hi      ; 0164: 00B2
        clrf            count   ; 0165: 01B3

loop_166
; jump here from: 00FC
; jump here from: 00FE
; jump here from: 0102
        movf            rcvbyte, W   ; 0166: 082D
        sublw           0x7e        ; 0167: 3C7E
        btfss           STATUS, Z   ; 0168: 1D03
        goto            loop_16c    ; 0169: 296C

        btfsc           isflag   ; 016A: 19AF
        goto            loop_216    ; 016B: 2A16

loop_16c
; jump here from: 0169
        movf            count, W   ; 016C: 0833
        sublw           0x02        ; 016D: 3C02
        btfsc           STATUS, C   ; 016E: 1803
        goto            loop_212    ; 016F: 2A12
        
        ; write received char to FRAM, checking for transparency
        
        ; accumulate checksum first
        
		movf	minus2, W
		xorwf	TXCRC, f
         
        movf            minus2, W   ; 0170: 082C
        xorlw           0xc0        ; 0171: 3AC0
        btfsc           STATUS, Z   ; 0172: 1903
        goto            charisFEND    ; 0173: 2978

        xorlw           0x1b        ; 0174: 3A1B
        btfsc           STATUS, Z   ; 0175: 1903
        goto            charisFESC    ; 0176: 29AB
        goto            label_1de   ; 0177: 29DE
;
; end of loop_16c
;------------------------------------------------------------

charisFEND

		movlw           0xdb        ; 0181: 30DB
		call	write_to_tnctohost_fram

        movlw           0xdc        ; 019A: 30DC
		call	write_to_tnctohost_fram
 
        goto            loop_1f7    ; 01AA: 29F7

charisFESC

		movlw           0xdb        ; 0181: 30DB
		call	write_to_tnctohost_fram

        movlw           0xdd
        call	write_to_tnctohost_fram

        goto            loop_1f7    ; 01DD: 29F7

label_1de
; jump here from: 0177 normal char

		movf            minus2, W   ; 01E7: 082C
		call	write_to_tnctohost_fram

loop_1f7
; jump here from: 01AA
; jump here from: 01DD
; jump here from: 01F0
; jump here from: 01F4

        movf            minus2, W   ; 01F7: 082C
        movwf           mem_61      ; 01F8: 00E1
        clrf            mem_62   ; 01F9: 01E2

;	Do CRC
label_1fa
; jump here from: 0211
        movf            mem_62, W   ; 01FA: 0862
        sublw           0x07        ; 01FB: 3C07
        btfss           STATUS, C   ; 01FC: 1C03
        goto            loop_212    ; 01FD: 2A12

        movf            mem_61, W   ; 01FE: 0861
        andlw           0x01        ; 01FF: 3901
        movwf           mem_63      ; 0200: 00E3
        bcf             STATUS, C   ; 0201: 1003
        rrf             crc_hi, f   ; 0202: 0CB2
        rrf             crc_lo, f   ; 0203: 0CB1
        movf            STATUS, W   ; 0204: 0803
        andlw           0x01        ; 0205: 3901
        xorwf           mem_63, W   ; 0206: 0663
        sublw           0x01        ; 0207: 3C01
        btfss           STATUS, Z   ; 0208: 1D03
        goto            loop_20e    ; 0209: 2A0E

        movlw           0x84        ; 020A: 3084
        xorwf           crc_hi, f   ; 020B: 06B2
        movlw           0x08        ; 020C: 3008
        xorwf           crc_lo, f   ; 020D: 06B1

loop_20e
; jump here from: 0209
        rrf             mem_61, W   ; 020E: 0C61
        rrf             mem_61, f   ; 020F: 0CE1
        incf            mem_62, f   ; 0210: 0AE2
        goto            label_1fa   ; 0211: 29FA

loop_212
; jump here from: 016F
; jump here from: 01FD
        movf            minus1, W   ; 0212: 082B
        movwf           minus2      ; 0213: 00AC
        movf            rcvbyte, W   ; 0214: 082D
        movwf           minus1      ; 0215: 00AB

loop_216
; jump here from: 016B
        clrf            bitcount   ; 0216: 01AE
        movf            bitcount, W   ; 0217: 082E
        movwf           rcvbyte      ; 0218: 00AD
        bcf             isflag   ; 0219: 11AF

loop_21a
; jump here from: 00EC
        bsf             INTCON, IOCIE; 021A: 158B
  
        movf            mem_23, W   ; 002C: 0823
        movwf           mem_77      ; 002D: 00F7
        movf            mem_24, W   ; 002E: 0824
        movwf           mem_78      ; 002F: 00F8
        movf            mem_25, W   ; 0030: 0825
        movwf           mem_79      ; 0031: 00F9
        movf            mem_26, W   ; 0032: 0826
        movwf           mem_7a      ; 0033: 00FA
        movf            mem_27, W   ; 0034: 0827
        movwf           mem_7b      ; 0035: 00FB

		retfie

INT_TIMER2

;	SLOTTIME Timer. This seems to run all the time there are frames to send
;	Although xmitlatch may be set while receiving, it will be cleared at end of RX
;
;	?? Shouldnt it be stopped if RXing ??

;void t2int(){
;    slotcount++;					//increments the variable slotcount every 10 ms;
;	if (slotcount > SLOTTIME){	//if elapsed time is greater than SLOTTIME x 10 ms
;		if (persist > rand()) xmitlatch = true;					//if persist passes, allow transmit
;		slotcount = 0;			//reset the elapsed time counter.
;    }
;    bit_clear(PIR1,1);
;}

	bcf	PIR1, TMR2IF
	
;	Doesn't use any regs

	decfsz	slotcount, f
	goto 	notslottime
    
;	Use Timer 0 as random number
    
	movf	TMR0, W
	swapf	WREG, W
		
	subwf  persist, W
       
	btfsc	STATUS, C
	bsf     xmitlatch, 0		; ok to transmit
        
	movf	slottime, W	
	movwf	slotcount
        
notslottime

	retfie
		
;	Subroutine: delay_us -  Microsecond delay

delay_us:

;	Count in WREG. 20 MHz clock, so 5 instructions per uS

	goto	$+1				; 2 cycles
	
	decfsz	WREG, f			; 1 cycle
	goto delay_us			; 2 cycles

	return
	

;------------------------------------------------------------
; Subroutine: delay_ms
;
delay_ms:

;	Count in WREG. 16 MHz clock, so 5 instructions per uS

	movwf	delay_ms_counter

delay_ms_outer_loop:

	movlw	250				; Use 250 * 5 uS delays
	
delay_ms_loop:

	call	dummy			; 4 cycles = 1 uS for call/return	
	call	dummy			; 1 uS for call/return	
	call	dummy			; 1 uS for call/return
	call	dummy
	
	nop						; 4 cycles for following 3 instructions
	decfsz	WREG, W
	goto delay_ms_loop			; 2 cycles
	
	decfsz	delay_ms_counter, f
	goto delay_ms_outer_loop			; 2 cycles
	
dummy:
	return


	
;------------------------------------------------------------
; Subroutine: 
;
; called from: 027E
; called from: 02FE
getc
        btfss           PIR1, RCIF  ; 0259: 1E8C
        goto            $-1         ; 025A: 2A59	Loop till ready

        MYBANKSEL RCSTA
        movf            RCSTA, W    ; 025B: 0818
        movwf           SaveRXStat      ; 025C: 00AA
        movf            RCREG, W    ; 025D: 081A

	    btfss           SaveRXStat, OERR   ; 025F: 1CAA
        goto            loop_263    ; 0260: 2A63

        bcf             RCSTA, CREN ; 0261: 1218	; clear error by stopping and restarting
        bsf             RCSTA, CREN ; 0262: 1618

loop_263
; jump here from: 0260
 		MYBANKSEL	STATUS
 		return
 
; end of label_000
;------------------------------------------------------------


;------------------------------------------------------------
; Subroutine: resetxmit
;
; called from: 04C8
; called from: 05CE

resetxmit
        bcf             PTT    ; 0265: 1006
        bcf             radtx    ; 0266: 1186
        bcf             m0    ; 0267: 1286
        clrf            C0xmit   ; 0268: 01B5
        movlw           0x08        ; 0269: 3008
        movwf           txinaddHi      ; 026A: 00BD
        clrf            txinaddLo   ; 026B: 01BC
        movwf           txoutaddHi      ; 026D: 00BF
        clrf           	txoutaddLo      ; 026F: 00BE
        bcf             xmiddle   ; 0270: 12AF
        
;	Delay 100 ms (10 * 10 ?? why)

        clrf            mem_51   ; 0271: 01D1

label_272
; jump here from: 027B
        movf            mem_51, W   ; 0272: 0851
        sublw           0x09        ; 0273: 3C09
        btfss           STATUS, C   ; 0274: 1C03
        goto            loop_27c    ; 0275: 2A7C

        movlw           0x0a        ; 0276: 300A
        call            delay_ms     ; 0278: 2245

        clrwdt                      ; 0279: 0064
        incf            mem_51, f   ; 027A: 0AD1
        goto            label_272   ; 027B: 2A72
        
; 	Clear chars from serial input

loop_27c
; jump here from: 0275
; jump here from: 028C
        btfss           PIR1, RCIF  ; 027C: 1E8C
        goto            loop_28d    ; 027D: 2A8D No more

        call            getc        ; Returns char in W - discard
        
 ; wait 25 * 10 ms
        
        clrf            mem_51   ; 0281: 01D1

label_282
; jump here from: 028B
        movf            mem_51, W   ; 0282: 0851
        sublw           0x18        ; 0283: 3C18
        btfss           STATUS, C   ; 0284: 1C03
        goto            loop_28c    ; 0285: 2A8C

        movlw           0x0a        ; 0286: 300A
        call            delay_ms     ; 0288: 2245

        clrwdt                      ; 0289: 0064
        incf            mem_51, f   ; 028A: 0AD1
        goto            label_282   ; 028B: 2A82

loop_28c
; jump here from: 0285
        goto            loop_27c    ; 028C: 2A7C
;
; end of loop_28c
;------------------------------------------------------------


loop_28d
; jump here from: 027D
        retlw           0x00        ; 028D: 3400
;
; end of label_000
;------------------------------------------------------------


;------------------------------------------------------------
; Subroutine: sendbyteserial
;
; called from: 053C
; called from: 055A
; called from: 06CE
; called from: 06EA

sendbyteserial

;int store;
;   if (bit_test(pir1,4)){                     //if the port is ready to receive data
;	  if (receivedpackets > 0){               //if there is data to send
;	    disable_interrupts(global);			  //don't allow interrupt of memory operation
;	    store = fram_read(rcvoutadd++);		  //get a byte from memory to route out serial port
;	    if (rcvoutadd == 2048) rcvoutadd = 0; //memory rollover, if necessary
;	    enable_interrupts(global);			  //interrupt ok now.
;	    if (store == 0xC0){				      //if we are on a packet boundary
;		    if (rmiddle){				      //if middle = true we have the ending C0
;			    rmiddle = false;		      //no longer in the middle
;		   	 receivedpackets--;		          //decrement the number of received packets.
;		    }else rmiddle = true;			  //if we weren't in the middle, we now are
;	    }
;	    putc(store);				          //send the data to the serial port
;	  }
;  }
;}

		btfsc	i2cmode			; if using i2c, dont sent to serial
		return
		
        btfss	PIR1, TXIF	; Busy?
        retlw	0x00		; Yes, so return

; With Polled KISS, we only start a frame if polled. Once started, we send it (them) all  

        btfsc	rmiddle		; Sending? - skip if not
        goto	SendNextByte
        
; We may be sending POLL ACK

		btfss	SendACK
		goto	notSendAck
		
		bcf		SendACK
		movf	OurChannel, W
		iorlw	POLL	; Send Poll as ACK
		ASYTX			; Send the ACK (with Channel bits set
		
		bsf		SendFEND
		retlw	0
		
notSendAck;		

		btfss	SendFEND
		goto	notSendFEND
		
; Send FEND to terminate Poll Response		
		
		bcf		SendFEND
		movlw	FEND
		ASYTX			; Send the FEND

		retlw	0
		
notSendFEND		
      
		btfss	PollMode	; Polled mode - skip if yes
		goto	CheckForMore; Not Polled, so send if available

;	We are in polled mode, so only send if polled.

		btfss	Polled
		retlw	0			; Not polled, so exit
		
; Polled. If data to send, send it, otherwise send Poll ACK

		bcf		Polled
        movf	receivedpackets, f
        btfss	STATUS, Z   ; skip if nothing to send
        goto	DataToSend
        
; Nothing to send - send Poll ACK (FEND POLL FEND)        

		movlw	FEND
		ASYTX			; Send the FEND
		
		bsf		SendACK	; Send ACK Byte next
		retlw	0
		
CheckForMore

        movf            receivedpackets, f   ; 02CC: 08B4
        btfsc           STATUS, Z   ; skip of something to send
        retlw	0
        
DataToSend:

SendNextByte:

		bcf		INTCON, GIE			; interrupts off
		call	read_from_tnctohost_fram
		bsf		INTCON, GIE			; interrupts back on
        movwf	work1
        
        sublw           0xc0        ; 02EE: 3CC0
        btfss           STATUS, Z   ; 02EF: 1D03
        goto            loop_2f7    ; 02F0: 2AF7

;	Got FEND

        btfss           rmiddle   ; 02F1: 1E2F
        goto            loop_2f6    ; 02F2: 2AF6

;	Was in frame, so now at end

        bcf             rmiddle   ; 02F3: 122F
        decf            receivedpackets, f   ; 02F4: 03B4
        goto            loop_2f7    ; 02F5: 2AF7

loop_2f6
; jump here from: 02F2
        bsf             rmiddle   ; 02F6: 162F	; Now in frame

loop_2f7
; jump here from: 02F0
; jump here from: 02F5
		movf            work1, W   ; 02F7: 084C
		ASYTX

loop_2fb
; jump here from: 02CB
; jump here from: 02CE
        retlw           0x00        ; 02FB: 3400
;
; end of label_000
;------------------------------------------------------------


;------------------------------------------------------------
; Subroutine: rcvbyteserial
;

rcvbyteserial
;    if (bit_test(pir1,5)){  				        //if there is a byte in the buffer
;         inbyt = getc();  				            //get the incoming byte

        btfss	PIR1, RCIF
        retlw	0
        
        call	getc
		movwf	inbyte
		
		btfsc	i2cmode				; if using i2c, dont use serial
		return
	
		bcf		INTCON, GIE			; interrupts off
		call	ProcessHostChar
		bsf		INTCON, GIE			; interrupts back on
 
		return


;------------------------------------------------------------
; Subroutine: sendbyte
;
; called from: 060B
; called from: 0610
; called from: 0613
; called from: 0648
; called from: 064D
; called from: 0657
; called from: 065C
; called from: 0660
; called from: 0681
; called from: 0684
; called from: 0689
; called from: 068C

sendbyte
        clrwdt                      ; 03D7: 0064
        clrf            mem_51   ; 03D8: 01D1

label_3d9
; jump here from: 041D
        movf            mem_51, W   ; 03D9: 0851
        sublw           0x07        ; 03DA: 3C07
        btfss           STATUS, C   ; 03DB: 1C03
        goto            loop_41e    ; 03DC: 2C1E

        movf            txbyte, W   ; 03DD: 0850
        andlw           0x01        ; 03DE: 3901
        movwf           mem_52      ; 03DF: 00D2

label_3e0
; jump here from: 03E5

;     while (get_rtcc() < 32) rcvbyteserial();		    //wait until 832 us have elapsed
				                   

        movf            TMR0, W     ; 03E0: 0801
        sublw           0x1f        ; 03E1: 3C1F
        btfss           STATUS, C   ; 03E2: 1C03
        goto            loop_3e6    ; 03E3: 2BE6

        call            rcvbyteserial     ; 03E4: 22FC
		
;	We need to call send routine as well, so we repond to polls while transmitting
;	Check timer again, to minimize jitter

		movf            TMR0, W     ; 03E0: 0801
        sublw           0x1f        ; 03E1: 3C1F
        btfss           STATUS, C   ; 03E2: 1C03
        goto            loop_3e6    ; 03E3: 2BE6

        call            sendbyteserial     ; 03E4: 22FC
       	goto            label_3e0   ; 03E5: 2BE0

loop_3e6
; jump here from: 03E3
;     delay_us(11);	 //timer resolution not good enough

        movlw           0x12        ; 03E6: 3012
        movwf           mem_77      ; 03E7: 00F7

        decfsz          mem_77, f   ; 03E8: 0BF7
        goto            $-1         ; 03E9: 2BE8

        clrf            TMR0     ; 03EA: 0181
        btfsc           crcflag   ; 03EB: 1BAF
        goto            loop_3fe    ; 03EC: 2BFE

        btfsc           flag   ; 03ED: 1B2F
        goto            loop_3fe    ; 03EE: 2BFE

        movf            mem_52, W   ; 03EF: 0852
        movwf           mem_53      ; 03F0: 00D3
        bcf             STATUS, C   ; 03F1: 1003
        rrf             xcrchi, f   ; 03F2: 0CC0
        rrf             xcrclo, f   ; 03F3: 0CC1
        movf            STATUS, W   ; 03F4: 0803
        andlw           0x01        ; 03F5: 3901
        xorwf           mem_53, W   ; 03F6: 0653
        sublw           0x01        ; 03F7: 3C01
        btfss           STATUS, Z   ; 03F8: 1D03
        goto            loop_3fe    ; 03F9: 2BFE

        movlw           0x84        ; 03FA: 3084
        xorwf           xcrchi, f   ; 03FB: 06C0
        movlw           0x08        ; 03FC: 3008
        xorwf           xcrclo, f   ; 03FD: 06C1

loop_3fe
; jump here from: 03EC
; jump here from: 03EE
; jump here from: 03F9
        movf            mem_52, f   ; 03FE: 08D2
        btfss           STATUS, Z   ; 03FF: 1D03
        goto            loop_405    ; 0400: 2C05

        clrf            stuff   ; 0401: 01C2
        movlw           0x08        ; 0402: 3008
        xorwf           PORTB, f    ; 0403: 0686
        goto            loop_41a    ; 0404: 2C1A

loop_405
; jump here from: 0400
        incf            stuff, f   ; 0405: 0AC2
        btfsc           flag   ; 0406: 1B2F
        goto            loop_41a    ; 0407: 2C1A

        movf            stuff, W   ; 0408: 0842
        sublw           0x05        ; 0409: 3C05
        btfss           STATUS, Z   ; 040A: 1D03
        goto            loop_41a    ; 040B: 2C1A

label_40c
; jump here from: 0411
        movf            TMR0, W     ; 040C: 0801
        sublw           0x1f        ; 040D: 3C1F
        btfss           STATUS, C   ; 040E: 1C03
        goto            loop_412    ; 040F: 2C12

        call            rcvbyteserial     ; 0410: 22FC

        goto            label_40c   ; 0411: 2C0C

loop_412
; jump here from: 040F
        movlw           0x12        ; 0412: 3012
        movwf           mem_77      ; 0413: 00F7

        decfsz          mem_77, f   ; 0414: 0BF7
        goto            $-1         ; 0415: 2C14

        clrf            TMR0     ; 0416: 0181
        clrf            stuff   ; 0417: 01C2
        movlw           0x08        ; 0418: 3008
        xorwf           PORTB, f    ; 0419: 0686

loop_41a
; jump here from: 0404
; jump here from: 0407
; jump here from: 040B
        rrf             txbyte, W   ; 041A: 0C50
        rrf             txbyte, f   ; 041B: 0CD0
        incf            mem_51, f   ; 041C: 0AD1
        goto            label_3d9   ; 041D: 2BD9

loop_41e
; jump here from: 03DC
        retlw           0x00        ; 041E: 3400
;
; end of label_000
;------------------------------------------------------------
EEREAD

	MYBANKSEL	EEADR
	movwf	EEADR
	bcf		EECON1, EEPGD
	bcf		EECON1, CFGS
	bsf		EECON1, RD
	movf	EEDAT, W
	MYBANKSEL STATUS
	return
		
EEWRITE:
;
;	Called with address in W, value in EEVAL, Interrupts off
;	Exits before write is complete - call EEWAIT if you need to be sure write has completed

	MYBANKSEL EEADR
	movwf	EEADR
	MYBANKSEL STATUS
	movf	EEVAL, W      
	MYBANKSEL EEDAT
 	movwf	EEDAT
	
	bcf		EECON1, EEPGD
	bcf		EECON1, CFGS
	bsf		EECON1, WREN
		
	movlw	0x55
	movwf	EECON2
	movlw	0xaa
	movwf	EECON2
 
	bsf		EECON1, WR
	bcf		EECON1, WREN

	MYBANKSEL STATUS
	return

EEWAIT:

	MYBANKSEL EECON1
	
	btfsc	EECON1, WR
	goto	$-1					; wait for completion
	    
	MYBANKSEL STATUS
	return
	
	
RXIdleChecks:

;	Things to do if not receiving

;	See if Reset or send params request
;	See if Data to send

	btfss	rebootFlag			; reset if reboot flag is set	
	goto	NoReset
	
	movlw	255
	call	delay_us
	call	delay_us
	call	delay_us
	call	delay_us

	reset
		
NoReset:

	call	sendbyteserial
	call	rcvbyteserial
	
	clrwdt

;	if a get params request has been received, send params now
;	(cant do if RX is active, as part frame may be in Ext RAM buffer

	btfss	sendparms
	goto	DontSendParams
	
	bcf 	sendparms
	
	movlw	0xc0
	call	write_to_tnctohost_fram
	
	movf	OurChannel, W
	iorlw	0x08					; Get Params Control
	movwf	TXCRC					; initialise checksum

	call	write_to_tnctohost_fram	
	
	call	EEWAIT
	
;
;	Send first 8 bytes of EEROM

	movlw	0
	call	EEREAD
	call	crc_check_and_write_to_host	; include in checksum and check for KISS Transparency

	movlw	1
	call	EEREAD
	call	crc_check_and_write_to_host

	movlw	2
	call	EEREAD
	call	crc_check_and_write_to_host

	movlw	3
	call	EEREAD
	call	crc_check_and_write_to_host

	movlw	4
	call	EEREAD
	call	crc_check_and_write_to_host

	movlw	5
	call	EEREAD
	call	crc_check_and_write_to_host

	movlw	6
	call	EEREAD
	call	crc_check_and_write_to_host

	movlw	7
	call	EEREAD
	call	crc_check_and_write_to_host
	
;	Send ADC Value

	MYBANKSEL ADCON0

	BSF		ADCON0,ADGO 	; Start conversion
	BTFSC	ADCON0,ADGO		; Is conversion done?
	GOTO	$-1 			; No, test again

	MYBANKSEL ADRESH
	MOVF	ADRESH,W 		; Read upper 8 bits
	lsrf	WREG,W			; Shift down one bit	

	
	MYBANKSEL STATUS
	call	crc_check_and_write_to_host

;	Send Checksum and FEND

	movf	TXCRC, w
	call	CheckKISS					; check for KISS Transparency
	call	write_to_tnctohost_fram
	
	movlw	0xc0
	call	write_to_tnctohost_fram
	
	incf	receivedpackets, f
	
DontSendParams	

;	See if packets to send
	
	movf            C0xmit, f   ; frames to send?
	btfsc           STATUS, Z   ; yes
	return						; nothingtosend
        
;	if CSMA alreasdy started, dont send on clear channel

	btfsc	DoingCSMA
	goto	CheckCSMA
	
;	If channel is clear, just send it. Only apply CSMA if channel is busy

	btfss	DCDLED					; Set when clear
	goto	WaitCSMA
	
	bsf		xmitlatch, 0
    call	xmit;
    
    return;

WaitCSMA:
     
;	enable timer2 interrupt if there is data to transmit

	MYBANKSEL	PIE1
	bsf		PIE1, TMR2IF
	MYBANKSEL STATUS
	
	bsf		DoingCSMA
	
CheckCSMA:

; 	If CSMA says OK to send, key transmitter

	btfss	xmitlatch, 0
	return
	
	call	xmit			; Send the frame(s)
	return

main:

;	Set Watchdog to 16 secs

	MYBANKSEL WDTCON
	
	movlw	b'00011100'			; 16 secs
	movwf	WDTCON
        
    MYBANKSEL ANSELA ; Select Bank of ANSEL

	MOVLW 	BIT1 ; Configure but A1 
	MOVWF 	ANSELA ; as digital i/o
		
	clrf	ANSELB
	
    MYBANKSEL	CM1CON0
	          
	clrf	CM1CON0       ; Comparater disabled
       
    ; SET_TRIS_A AND B
        
	MYBANKSEL TRISA
	
	movlw	BIT1        ; 1 = input 0 -= output A1 is analog input to DAC
	movwf	TRISA
       
	MYBANKSEL	TRISB
	
	;	I2C Uses B1 and B4, which should be set as inputs. RXD = 2, radrx = 6
	
		movlw	BIT1 | BIT2 | BIT4 | BIT6
		movwf	TRISB

	; Move TX and RX to alt locations (RB2 /RB5)  
        
	MYBANKSEL APFCON0
	
		clrf	APFCON0
		bsf		APFCON0, RXDTSEL
		
		clrf	APFCON1
		bsf		APFCON1, TXCKSEL

;	Set up ADC for TXD control

	MYBANKSEL ADCON1
	movlw	B'00100000' 	; Left justify, FOSC/32 clock Vdd and Vss Vref
	movwf	ADCON1
	
	MYBANKSEL ADCON0
	movlw	b'00000101' 	; Select channel AN1 Turn ADC On
	movwf ADCON0
	
	MYBANKSEL	STATUS
	
	clrf	bpqflags
	clrf	AcksToSendCount
	clrf	txflags
	clrf	boolflags
	clrf	kissflags
	
loopx
	
	bcf		DCDLED			; DCD and PTT on
	bsf		PTT
	bsf		m0
		
	movlw	0xff
	call	delay_ms
	call	delay_ms
	
	bcf		PTT				; PTT off
	
	movlw	0xff
	call	delay_ms
	call	delay_ms

	bsf		DCDLED			; DCD off
	bcf		m0
		
;		Set for 16 bit BRG, to get better accuracy at 115.2K

	    MYBANKSEL		SPBRGL			; aLL uart REGS IN SAME BANK (3)
	    	   
		movlw	1 << BRG16
		movwf	BAUDCON

		movlw	3		; Set Serial port to 19200 (259)
		movwf	SPBRGL
		movlw	1
		movwf	SPBRGH
       
		movlw	1 << TXEN | 1 << BRGH
		movwf	TXSTA

		movlw	1 << SPEN | 1 << CREN
		movwf	RCSTA
        
 	MYBANKSEL	STATUS  
   		
	;	Set up i2c
	
	MYBANKSEL	PORTB
	clrf	PORTB
	clrf	PIR1
		
	movlw	0x36 ; Setup SSP module for 7-bit
	MYBANKSEL	SSP1CON1
	movwf	SSP1CON1 ; address, slave mode
		
	bsf		SSP1CON2, SEN	; Extend Clock on all transactions
		
;	movlw	3
;	movwf	SSP1CON3
		
	movlw	I2CADDRESS
	call	EEREAD
	
	movf	WREG, w			; test
	btfsc	STATUS, Z
	goto	skipi2c
		
	bsf		i2cmode			; if using i2c, dont sent to serial
	bsf		HOSTCRC			; i2c needs crc
	
	lslf	WREG,W			; Shift up one bit	
	MYBANKSEL	SSP1ADD
	movwf	SSP1ADD
		
	MYBANKSEL	SSP1STAT
	clrf	SSP1STAT
	MYBANKSEL PIE1 			; Enable interrupts
	bsf		PIE1,SSP1IE
	
skipi2c:

	MYBANKSEL STATUS
        
        bcf             isflag
        bcf             rmiddle
        bcf             xmiddle
        clrf            xmitlatch
        clrf            slotcount
    
	bcf		PIR2, C1IF  ; PIR1-4 all in bank 0
 	
	;	Set radrx bit interrupt on change (both up and down)
	
	MYBANKSEL IOCBP
	movlw	radrxbit
	movwf	IOCBP
	movwf	IOCBN

	MYBANKSEL	STATUS

 	bsf	DCDLED
	
        bsf             PTT    ; 044B: 1006
        bsf             m0    ; 044C: 1686
        bsf             m1    ; 044D: 1606
        bsf             PORTA, csbit			; release FRAMM CS
          
        movlw           10
        call            delay_ms     ; 0451: 2245

        bcf             m1    ; 0452: 1206
        bcf             m0    ; 0453: 1286
        
;   MYBANKSEL	OPTION_REG
;        bcf             OPTION_REG, 7     ; 0455: 1381	Pullups on B
;  MYBANKSEL	STATUS  
   	
       
;  setup_timer_2(T2_DIV_BY_16, 0xC3, 16);	//when turned on, will interrupt every 10 ms

        movlw	0x7E
        movwf	T2CON       ; Set Control (Bank 0)
        
        movlw	0xc3
	MYBANKSEL PR2
        movwf	PR2		; Should give 10 ms Set Period
        
; set timer 4 to run from system clock - used for rand()

	MYBANKSEL	T4CON

	movlw	0x04		; Timer On Prescale and Postscale = 1
	movwf	T4CON
        
    MYBANKSEL	STATUS

	clrf	C0xmit
	clrf	receivedpackets

;   setup_counters(RTCC_INTERNAL,RTCC_DIV_128); 
  
	MYBANKSEL	OPTION_REG
	
	MOVLW 	B'10000110'	; Pullup off, Int Edge, Internal, Tmr Edge, Prescale, x 128
	MOVWF OPTION_REG

	MYBANKSEL STATUS
         
        clrf	rcvoutaddHi   ; 04B8: 01B9
        clrf	rcvoutaddLo   ; 04B9: 01B8
        clrf	rcvinaddHi      ; 04BB: 00B7
        clrf	rcvinaddLo      ; 04BD: 00B6
        clrf	beginHi   ; 04BE: 01BB
        clrf	beginLo      ; 04C0: 00BA
      
        call	resetxmit     ; 04C8: 2265
               
;	Read params from EEPROM

		movlw	KISSCHANNEL
		call	EEREAD
		btfsc	WREG, 0			; Bottom bit for polled
		bsf		PollMode		; Set Polled Mode
		btfsc	WREG, 1			; Bottom bit for polled
		bsf		HOSTCRC			; Set CRC Mode
		
		andlw	0xf0;			; Mask bottom bit
		movwf	OurChannel
				
		movlw	PERSIST
		call	EEREAD
   	    movwf	persist
 		
        movlw	SLOTTIME
        call	EEREAD
        movwf	slottime
        
        movlw	TXDELAY
        call	EEREAD
        movwf	txdelay

	IF 0
	
	; Test FRAM

		movlw	2
		movwf	receivedpackets
		
		movlw FEND
		call	write_to_tnctohost_fram
        
  		movlw 00
		call	write_to_tnctohost_fram
 
  		movlw 01
		call	write_to_tnctohost_fram
 
  		movlw 02
		call	write_to_tnctohost_fram
 
  		movlw 03
		call	write_to_tnctohost_fram
 
  
 		movlw FEND
		call	write_to_tnctohost_fram
        
 		movlw FEND
		call	write_to_tnctohost_fram
        
  		movlw 00
		call	write_to_tnctohost_fram
 
  		movlw 01
		call	write_to_tnctohost_fram
 
  		movlw 02
		call	write_to_tnctohost_fram
 
  		movlw 03
		call	write_to_tnctohost_fram
 
  
 		movlw FEND
		call	write_to_tnctohost_fram

;		call	read_from_tnctohost_fram
 
 
 	ENDIF
 	
        movlw           0xc0        ; 04D9: 30C0 PEIE + GIE
        iorwf           INTCON, f   ; 04DA: 048B
        
MainLoop: 

;	set up next packet to be received

	movlw	0xff
	movwf	crc_hi
	movwf	crc_lo
        
	bcf		fiveones   ; 04E4: 10AF
	bcf		done   ; 04E5: 112F
	clrf	count   ; 04E6: 01B3
        
	clrf	bitcount      ; 04E8: 00AE
	clrf	rcvbyte      ; 04E9: 00AD
	clrf	ones      ; 04EA: 00B0
     
;	Seems to be inlined findflag

;	int time, countlegal, freetime = 0;
;	oldstate = input(radrx);  				                      //remember the state of input pin
	
        bcf		oldstate
		btfsc	radrx
        bsf		oldstate	; oldstate = radrx
        
waitchange1

;	while (input(radrx) == oldstate){			                  //wait for a change on the input pin
;		 sendbyteserial(); 				                          //in the meantime, process data to/from serial port
;		 rcvbyteserial();
;		 restart_wdt();
;	}

	movlw	0x00
    btfsc	radrx
	movlw	0x01		; W = state of radrx (bit 0 of boolflags)
           
	xorwf	boolflags, W	; Bottom bit of W is set if changed
	btfsc	WREG, 0
	goto	firstchange    ; 053B: 2D40
        
	call	RXIdleChecks 
	      
	goto	waitchange1   ; 053F: 2D32

firstchange

;	Seen a transition - start timer to see if valid preamble

;	set_rtcc(0);						                          //set clock to 0
	
	clrf	TMR0     ; 0540: 0181
	
	movlw	0x01			; oldstate is bit 0 of boolflags
	xorwf	boolflags, f	; toggle bit  //since the state changed, flip oldstate
        	
loop_54a

waitlonger:
	
; while (input(radrx) == oldstate){
; jump here from: 054C
; jump here from: 0698
       
       	movlw	0x00
        btfsc	radrx
        movlw	0x01		; W = radrx (bit 0 of boolflags)
           
        xorwf	boolflags, W	; Bit zero of W set if changed
        btfsc	WREG, 0
        goto	secondchange    ; Changed

	call	RXIdleChecks 

	goto	waitlonger
	
secondchange:
;
;	input has changed again
;
;	Look for valid preamble - zeros or flags

        movf            TMR0, W     ; 0699: 0801
        movwf           mem_49      ; 069A: 00C9
        clrf            TMR0    ; 069B: 0181
        movlw           0x00        ; 069C: 3000
        btfss           oldstate   ; 069D: 1C2F
        movlw           0x01        ; 069E: 3001
        movwf           mem_78      ; 069F: 00F8
        btfsc           mem_78, 0   ; 06A0: 1878
        goto            loop_6a4    ; 06A1: 2EA4

        bcf             oldstate   ; 06A2: 102F
        goto            label_6a5   ; 06A3: 2EA5

loop_6a4
; jump here from: 06A1
        bsf             oldstate   ; 06A4: 142F

;	looking for a zero  (a legal interval)

label_6a5
; jump here from: 06A3
        movf            mem_49, W   ; 06A5: 0849
        sublw           0x1d        ; 06A6: 3C1D
        btfsc           STATUS, C   ; 06A7: 1803
        goto            loop_6af    ; 06A8: 2EAF

        movf            mem_49, W   ; 06A9: 0849
        sublw           0x22        ; 06AA: 3C22
        btfss           STATUS, C   ; 06AB: 1C03
        goto            loop_6af    ; 06AC: 2EAF

        incf            mem_4a, f   ; 06AD: 0ACA
        goto            label_6bb   ; 06AE: 2EBB

loop_6af

; looking for 6 ones (a flag... legal interval) Transmission will idle on 0x00 or 0x7E

; jump here from: 06A8
; jump here from: 06AC
        movf            mem_49, W   ; 06AF: 0849
        sublw           0xdd        ; 06B0: 3CDD
        btfsc           STATUS, C   ; 06B1: 1803
        goto            loop_6ba    ; 06B2: 2EBA

        movf            mem_49, W   ; 06B3: 0849
        sublw           0xe9        ; 06B4: 3CE9
        btfss           STATUS, C   ; 06B5: 1C03
        goto            loop_6ba    ; 06B6: 2EBA

        movlw           0x03        ; 06B7: 3003
        addwf           mem_4a, f   ; 06B8: 07CA
        goto            label_6bb   ; 06B9: 2EBB

loop_6ba
; jump here from: 06B2
; jump here from: 06B6
        clrf            mem_4a   ; 06BA: 01CA

label_6bb
; jump here from: 06AE
; jump here from: 06B9
        movf            mem_4a, W   ; 06BB: 084A
        sublw           0x04        ; 06BC: 3C04
        btfsc           STATUS, C   ; 06BD: 1803
        goto            loop_54a    ; 06BE: 2D4A

; Receiving what looks like good data. don't transmit while data is being received.

	MYBANKSEL	PIE1
	bcf		PIE1, TMR2IF				; Stop CSMA Timer
	MYBANKSEL	STATUS
	
    movf	slottime, W
	movwf	slotcount   				; Ready for restart of CSMA
	bcf		xmitlatch, 0				; in case already set
	
	bcf		DCDLED						; Put LED on when receiving preamble

loop_6c4

;	Look for FLAG

        movlw           0x00        ; 06C4: 3000
        btfsc           radrx    ; 06C5: 1B06
        movlw           0x01        ; 06C6: 3001
        movwf           work1      ; 06C7: 00CC
        movlw           0x00        ; 06C8: 3000
        btfsc           oldstate   ; 06C9: 182F
        movlw           0x01        ; 06CA: 3001
        subwf           work1, W   ; 06CB: 024C
        btfss           STATUS, Z   ; 06CC: 1D03
        goto            loop_6d2    ; 06CD: 2ED2

;		???????????? is this safe - if we stop receiving bits while waiting for flag

        call            sendbyteserial     ; 06CE: 22CA

        call            rcvbyteserial     ; 06CF: 22FC

        clrwdt                      ; 06D0: 0064
        goto            loop_6c4    ; 06D1: 2EC4

loop_6d2
; jump here from: 06CD
        movf            TMR0, W     ; 06D2: 0801
        movwf           mem_49      ; 06D3: 00C9
        clrf            TMR0     ; 06D4: 0181
        movlw           0x00        ; 06D5: 3000
        btfss           oldstate   ; 06D6: 1C2F
        movlw           0x01        ; 06D7: 3001
        movwf           mem_78      ; 06D8: 00F8
        btfsc           mem_78, 0   ; 06D9: 1878
        goto            loop_6dd    ; 06DA: 2EDD

        bcf             oldstate   ; 06DB: 102F
        goto            label_6de   ; 06DC: 2EDE

loop_6dd
; jump here from: 06DA
        bsf             oldstate   ; 06DD: 142F

label_6de
; jump here from: 06DC
        movf            mem_49, W   ; 06DE: 0849
        sublw           0xd1        ; 06DF: 3CD1
        btfsc           STATUS, C   ; 06E0: 1803
        goto            loop_6c4    ; 06E1: 2EC4
        
; ?? end of inlined findflag



;   output_low(LED);				                      	//packet is here, turn on DCD LED
;  	     set_rtcc(207);					                      	//delay 1.5 bit intervals to get to the middle of the next bit.
;	     bit_clear(intcon,2);				                   	//don't get an interrupt right away
;	     enable_interrupts(INT_RTCC | INT_RB );	 		//enable interrutps to begin to collect data

;	Save start of frame (in case frame is duff)
	
        movf            rcvinaddHi, W   ; 015E: 0837
        movwf           beginHi      ; 015F: 00BB
        movf            rcvinaddLo, W   ; 0160: 0836
        movwf           beginLo      ; 0161: 00BA
        
        clrf	FrameBits

;	Write FEND and control byte to buffer
        
        movlw	0xc0        ; 04F8: 30C0
 
 		call	write_to_tnctohost_fram

;	writing the control byte - add in address bits
        
        movf	OurChannel, W
        movwf	TXCRC				; initialise checksum
        
 		call	write_to_tnctohost_fram
	 
        movlw           0xcf        ; 06E3: 30CF
        movwf           TMR0        ; 06E4: 0081
        bcf             INTCON, TMR0IF; 06E5: 110B
        movlw           0x28        ; 06E6: 3028
        iorwf           INTCON, f   ; 06E7: 048B

label_6e8

;	We loop here till interrupt level says packet is complete or duff

        btfsc           done   ; 06E8: 192F
        goto            rxcomplete    ; 06E9: 2EEE

        call            sendbyteserial     ; 06EA: 22CA
        call            rcvbyteserial     ; 06EB: 22FC

        clrwdt                      ; 06EC: 0064
        goto            label_6e8   ; 06ED: 2EE8

rxcomplete:

; Packet is complete

;	     output_high(LED);				                      	//packet is over, turn off DCD LED
;		 if (SLOTTIME > 0){									
	
;	//reset transmit holdoff counter unless SLOTTIME == 0)
;			xmitlatch = false; 
;			set_timer2(0); 
;			slotcount = 0;	
 ;       }
;	     disable_interrupts(INT_RTCC |INT_RB );   				//disable interrupts to prepare for next findflag

;	Packet has ended. If we have stuff queued to transmit, start CSMA

	bsf	DCDLED
	
	movf	slottime, f
	movwf	slotcount				; Counts down
	bcf		xmitlatch, 0   			; Cancel any pending TX and reschedule
	clrf	TMR2

IOCIF            EQU  H'0000'
INTF             EQU  H'0001'
TMR0IF           EQU  H'0002'
IOCIE            EQU  H'0003'
INTE             EQU  H'0004'
TMR0IE           EQU  H'0005'
PEIE             EQU  H'0006'
GIE              EQU  H'0007'

T0IF             EQU  H'0002'
T0IE             EQU  H'0005'

	bcf		INTCON, IOCIE			; Pin Change
	bcf		INTCON, TMR0IE			; Timer 0		

	goto	MainLoop


xmit:

        bcf             DB   ; 055F: 104F
        bsf             firstpac   ; 0560: 14CF
        
seeifmoretosend:

        movf            C0xmit, f   ; 0561: 08B5
        btfss           STATUS, Z   ; 0562: 1903
        goto            moretosend    ; 0563: 2E90	No more to send

;	All sent - Now sned any outstanding ACKS

	movf	AcksToSendCount, W
	addwf	receivedpackets, f	
	clrf	AcksToSendCount	

	bcf		PTT					; unkey PTT
	bcf		radtx    			; leave transmit pin low
	bcf		m0					; MX 614 to recv mode
        
	MYBANKSEL	PIE1
	bcf			PIE1, TMR2IF	; Stop slottime/persist timer ints
	MYBANKSEL	STATUS
	        
	clrf            slotcount   ; 0696: 01C6
	bcf             xmitlatch, 0   ; 0697: 1043

	bcf		DoingCSMA
        
	return

moretosend:

; New frame to send

        clrf            stuff   ; 0564: 01C2
        bcf             crcflag   ; 0565: 13AF
        movlw           0xff        ; 0566: 30FF
        movwf           xcrchi      ; 0567: 00C0
        movwf           xcrclo      ; 0568: 00C1
        bsf             m0    ; 0569: 1686	Modem M0 line
        
        ; get and discard FEND
        
        call	read_from_hosttotnc_fram
        
	; Get control
	
	    call	read_from_hosttotnc_fram

;	Control Byte should only be 00 or 0C

		btfsc           STATUS, Z   ; 05C7: 1903
		goto datactrl
       
		sublw           ACK        ; 05CA: 3C06
      
		btfsc           STATUS, Z   ; 05C7: 1903
		goto ACKctrl
        
;	Duff Frame

		bcf             PTT    ; 05CD: 1006		; PTT?
		call            resetxmit     ; 05CE: 2265

	return
        
        
ACKctrl

;	Ack Mode Frame. First two bytes of frame must be returned to host when frame is sent

		call	read_from_hosttotnc_fram
 		movwf	AckByte1
 		
		call	read_from_hosttotnc_fram
 		movwf	AckByte2
 		
 		bsf		FrameNeedsACK
 		
datactrl
       
        bsf             PTT    ; 05C8: 1406		; Set PTT
 
loop_5d0
; jump here from: 05CC

        btfss           firstpac   ; 05D0: 1CCF
        goto            notfirst    ; 05D1: 2E16
        
;	if first of a sequence, set TXDELAY

	movf	txdelay, W
	
;	if EEPROM value is zero, get from ADC

	btfss	STATUS, Z
	goto 	noadc
	
	MYBANKSEL ADCON0

	BSF		ADCON0,ADGO 		; Start conversion
	BTFSC	ADCON0,ADGO			; Is conversion done?
	GOTO	$-1 				; No, test again

	MYBANKSEL ADRESH
	MOVF	ADRESH,W 			; Read upper 8 bits
	lsrf	WREG,W				; Shift down one bit. Gives about 0 - 75 (0 to 500 ms)	
	incf	WREG,W				; ensure non-zero
	
	MYBANKSEL STATUS

noadc:

	movwf	work1
	    
	bsf		flag
	clrf	TMR0
	
txdloop:

	clrf	txbyte
	call	sendbyte
	
	decfsz	work1, f
	goto	txdloop
        
;	Try sending a couple of flags between frames

notfirst

		bsf		flag
        movlw           0x7e        ; 060E: 307E
        movwf           txbyte      ; 060F: 00D0
        call            sendbyte     ; 0610: 23D7

        movlw           0x7e        ; 0611: 307E
        movwf           txbyte      ; 0612: 00D0
        call            sendbyte     ; 0613: 23D7

        bcf             flag   ; 0614: 132F
        bcf             firstpac   ; 0615: 10CF

;notfirst

		call	read_from_hosttotnc_fram	; Get first byte to send
		
        movwf           mem_4d      ; 0624: 00CD
        
;	Send Frame, doing KISS transparency

sendnextbyte
        
        sublw           0xc0        ; 0630: 3CC0
        btfsc           STATUS, Z   ; 0631: 1903
        goto            txendofmsg   ; 0632: 2E7B

        movf            mem_4d, W   ; 0633: 084D
        xorlw           0xdb        ; 0634: 3ADB
        btfsc           STATUS, Z   ; 0635: 1903
        goto            loop_63e    ; 0636: 2E3E

        xorlw           0x07        ; 0637: 3A07
        btfsc           STATUS, Z   ; 0638: 1903
        goto            loop_640    ; 0639: 2E40

        xorlw           0x01        ; 063A: 3A01
        btfsc           STATUS, Z   ; 063B: 1903
        goto            loop_64f    ; 063C: 2E4F
        goto            label_65e   ; 063D: 2E5E
;
; end of loop_62f
;------------------------------------------------------------


loop_63e
; jump here from: 0636
        bsf             DB   ; 063E: 144F
        goto            label_661   ; 063F: 2E61

loop_640
; jump here from: 0639
        movlw           0x00        ; 0640: 3000
        btfsc           DB   ; 0641: 184F
        movlw           0x01        ; 0642: 3001
        sublw           0x01        ; 0643: 3C01
        btfss           STATUS, Z   ; 0644: 1D03
        goto            loop_64b    ; 0645: 2E4B

        movlw           0xc0        ; 0646: 30C0
        movwf           txbyte      ; 0647: 00D0
        call            sendbyte     ; 0648: 23D7

        bcf             DB   ; 0649: 104F
        goto            label_64e   ; 064A: 2E4E

loop_64b
; jump here from: 0645
        movlw           0xdc        ; 064B: 30DC
        movwf           txbyte      ; 064C: 00D0
        call            sendbyte     ; 064D: 23D7

label_64e
; jump here from: 064A
        goto            label_661   ; 064E: 2E61

loop_64f
; jump here from: 063C
        movlw           0x00        ; 064F: 3000
        btfsc           DB   ; 0650: 184F
        movlw           0x01        ; 0651: 3001
        sublw           0x01        ; 0652: 3C01
        btfss           STATUS, Z   ; 0653: 1D03
        goto            loop_65a    ; 0654: 2E5A

        movlw           0xdb        ; 0655: 30DB
        movwf           txbyte      ; 0656: 00D0
        call            sendbyte     ; 0657: 23D7

        bcf             DB   ; 0658: 104F
        goto            label_65d   ; 0659: 2E5D

loop_65a
; jump here from: 0654
        movlw           0xdd        ; 065A: 30DD
        movwf           txbyte      ; 065B: 00D0
        call            sendbyte     ; 065C: 23D7

label_65d
; jump here from: 0659
        goto            label_661   ; 065D: 2E61

label_65e
; jump here from: 063D
        movf            mem_4d, W   ; 065E: 084D
        movwf           txbyte      ; 065F: 00D0
        call            sendbyte     ; 0660: 23D7

label_661

		call	read_from_hosttotnc_fram	; Get first byte to send
 		movwf	mem_4d
 		
        goto	sendnextbyte

txendofmsg

;	Just read FEND from buffer

        bsf             crcflag   ; 067B: 17AF
        movlw           0xff        ; 067C: 30FF
        xorwf           xcrclo, f   ; 067D: 06C1
        xorwf           xcrchi, f   ; 067E: 06C0
        movf            xcrclo, W   ; 067F: 0841
        movwf           txbyte      ; 0680: 00D0
        call            sendbyte     ; 0681: 23D7

        movf            xcrchi, W   ; 0682: 0840
        movwf           txbyte      ; 0683: 00D0
        call            sendbyte     ; 0684: 23D7

        bsf             flag   ; 0685: 172F
        bcf             crcflag   ; 0686: 13AF
        movlw           0x7e        ; 0687: 307E
        movwf           txbyte      ; 0688: 00D0
        call            sendbyte     ; 0689: 23D7

        movlw           0x7e        ; 068A: 307E
        movwf           txbyte      ; 068B: 00D0
        call            sendbyte     ; 068C: 23D7

        bcf             flag   ; 068D: 132F
        decf            C0xmit, f   ; 068E: 03B5
        
;	We have sent whole frame - return ack byte if needed        
        
		btfss	FrameNeedsACK 
		goto dontneedack      

;	put ack frame into fram buffer

		bcf		FrameNeedsACK 

		movlw	FEND
 		call	write_to_tnctohost_fram
		
		movf	OurChannel, W
		iorlw	ACK	
	
 		call	write_to_tnctohost_fram

		movf	AckByte1, W
		
 		call	write_to_tnctohost_fram

		movF	AckByte2, W
 		call	write_to_tnctohost_fram

		movlw	FEND
 		call	write_to_tnctohost_fram

		incf	AcksToSendCount, f

dontneedack

	goto	seeifmoretosend

                                 ; 2007: 3F02
write_to_tnctohost_fram

;	This is called a lot, so worth making a subroutine.
;	Inline the call to fram_write, to avoid another stack level and 
;	to save a lot of register juggling

;	value to write is in W


;fram_write
        
;    output_low(cs);
;    fram_bits(0b00000110); 		  // set write enable latch
;    output_high(cs);

;	Turn off interrupts if on

        clrf            mem_29   ; 0299: 01A9
        btfsc           INTCON, GIE ; 029A: 1B8B
        bsf             mem_29, 7   ; 029B: 17A9
        bcf             INTCON, GIE ; 029C: 138B 

		movwf           mem_63		; Save value to write       
        bcf             PORTA, csbit    ; 006C: 1185
        
        movlw           0x06        ; 006D: 3006
        movwf           mem_68      ; 006E: 00E8   
        call            fram_bits     ; 006F: 204E

        bsf             PORTA, csbit   ; 0070: 1585
        
;    output_low(cs);
;    fram_bits(0b00000010);		     //this is a write
        
        bcf             PORTA, csbit    ; 0071: 1185
        movlw           0x02        ; 0072: 3002
        movwf           mem_68      ; 0073: 00E8
        call            fram_bits     ; 0074: 204E

;    fram_bits(hiaddr);			     //write the two byte address

        movf            rcvinaddHi, W   ; 0075: 0866
        movwf           mem_68      ; 0076: 00E8
        call            fram_bits     ; 0077: 204E

;    fram_bits(loaddr);

        movf            rcvinaddLo, W   ; 0078: 0867
        movwf           mem_68      ; 0079: 00E8
        call            fram_bits     ; 007A: 204E

;    fram_bits(byt);			        //write the data
 
        movf            mem_63, W   ; 007B: 0863
        movwf           mem_68      ; 007C: 00E8
        call            fram_bits     ; 007D: 204E

;    output_high(cs);			       //all done

        bsf             PORTA, csbit    ; 007E: 1585
        
		btfsc           mem_29, 7   ; 02A0: 1BA9
        bsf             INTCON, GIE ; 02A1: 178B

        
; End of inlined fram_write
;       
        
        incf	rcvinaddLo, f
        btfss	STATUS, Z		;wrapped?
       	retlw	0x00			; no so return

		incf	rcvinaddHi, f

        movf 	rcvinaddHi, W		; end of buffer?
        sublw	0x08
        btfss	STATUS, Z   		; skip if yes
       	retlw	0x00			; no so return

        clrf	rcvinaddHi   	; Clear ho byte
       	retlw	0x00			; rcvinaddLo is already zero

write_to_hosttotnc_fram

;	This is called a lot, so worth making a subroutine.
;	Inline the call to fram_write, to avoid another stack level and 
;	to save a lot of register juggling

;	value to write is in W

;	Called from I2C interrupt routine, with ints off, and BANK = 0

		movwf           mem_63		; Save value to write

;fram_write
        
;    output_low(cs);
;    fram_bits(0b00000110); 		  // set write enable latch
;    output_high(cs);
       
        bcf             PORTA, csbit    ; 006C: 1185
        
        movlw           0x06        ; 006D: 3006
        movwf           mem_68      ; 006E: 00E8   
        call            fram_bits     ; 006F: 204E

        bsf             PORTA, csbit    ; 0070: 1585
        
;    output_low(cs);
;    fram_bits(0b00000010);		     //this is a write
        
        bcf             PORTA, csbit    ; 0071: 1185
        movlw           0x02        ; 0072: 3002
        movwf           mem_68      ; 0073: 00E8
        call            fram_bits     ; 0074: 204E

;    fram_bits(hiaddr);			     //write the two byte address

        movf            txinaddHi, W   ; 0075: 0866
        movwf           mem_68      ; 0076: 00E8
        call            fram_bits     ; 0077: 204E

;    fram_bits(loaddr);

        movf            txinaddLo, W   ; 0078: 0867
        movwf           mem_68      ; 0079: 00E8
        call            fram_bits     ; 007A: 204E

;    fram_bits(byt);			        //write the data
 
        movf            mem_63, W   ; 007B: 0863
        movwf           mem_68      ; 007C: 00E8
        call            fram_bits     ; 007D: 204E

;    output_high(cs);			       //all done

        bsf             PORTA, csbit    ; 007E: 1585
        
; End of inlined fram_write
;
        incf	txinaddLo, f
        btfss	STATUS, Z		;wrapped?
       	retlw	0x00			; no so return

;	Low byte wrapped, so increment hi

		incf	txinaddHi, f
        movf 	txinaddHi, W	; end of buffer?
        sublw	0x20
        btfss	STATUS, Z
       	retlw	0x00			; no so return

        movlw	0x08
        movwf	txinaddHi 		; reset hi byte to start of buffer
       	retlw	0x00			; Lo is already zero
       	
read_from_hosttotnc_fram
         
;int fram_read(long addr){   		//read a byte from FRAM
;int inbyte,bitc, hiaddr, loaddr;
;   hiaddr = (int) (addr >> 8);
;   loaddr = (int) (addr & 0xFF);
;   set_tris_a(0b100000);
;   output_low(cs);

        bcf		INTCON, GIE	; Clear interrupts while writing to FRAM

        bcf             PORTA, csbit    ; 0298: 1185

;   fram_bits(0b00000011);		   //this is a read

		movlw           0x03        ; 029D: 3003
        movwf           mem_68      ; 029E: 00E8
        call            fram_bits     ; 029F: 204E

;   fram_bits(hiaddr);			   //send the two byte address
;   fram_bits(loaddr);

        movf            txoutaddHi, W   ; 02AF: 0859
        movwf           mem_68      ; 02B0: 00E8
        call            fram_bits     ; 02A8: 204E

        movf            txoutaddLo, W   ; 02AF: 0859
        movwf           mem_68      ; 02B0: 00E8
        call            fram_bits     ; 02B1: 204E
        
        
;   set_tris_a(0b100100);  		   //set I/O to read from FRAM

      movlw           0x06        ; 02B4: 3024
      tris            0x05        ; 02B5: 0065
            
  ;   inbyte = 0;
;   for(bitc=0;bitc<8;bitc++){		//clock in the bits
	
      clrf            mem_56   ; 02B6: 01D6
      clrf            mem_57   ; 02B7: 01D7

bitloop

; jump here from: 02C3
        movf            mem_57, W   ; 02B8: 0857
        sublw           0x07        ; 02B9: 3C07
        btfss           STATUS, C   ; 02BA: 1C03
        goto            endbitloop    ; 02BB: 2AC4
        
;         output_high(clock);

        bsf             PORTA, clockbit    ; 02BC: 1405
        
;         if (input(data)) (inbyte++);

        btfsc           PORTA, databit    ; 02BD: 1905
        incf            mem_56, f   ; 02BE: 0AD6
        
;         output_low(clock);

        bcf             PORTA, clockbit    ; 02BF: 1005
 
;         rotate_left(&inbyte,1);

        rlf             mem_56, W   ; 02C0: 0D56
        rlf             mem_56, f   ; 02C1: 0DD6

;    }
        incf            mem_57, f   ; 02C2: 0AD7
        goto            bitloop   ; 02C3: 2AB8

endbitloop

;    rotate_right(&inbyte,1);

        rrf             mem_56, W   ; 02C4: 0C56
        rrf             mem_56, f   ; 02C5: 0CD6
        
;    output_high(cs);			      //add done

        bsf             PORTA, csbit    ; 02C6: 1585
		
		movlw           0x02        ; 02B4: 3024
		tris            0x05        ; 02B5: 0065
        
		bsf		INTCON, GIE			; interrupts back on

; 	Increment address

       	incf	txoutaddLo, f
        btfss	STATUS, Z		;wrapped?
       	goto 	returnval		; no so return

;	Low byte wrapped, so increment hi

		incf	txoutaddHi, f
        movf 	txoutaddHi, W	; end of buffer?
        sublw	0x20
        btfss	STATUS, Z
       	goto returnval			; no so return

        movlw	0x08
        movwf	txoutaddHi 		; reset hi byte to start of buffer
        
returnval

		movf	mem_56, W 
		return					; With result in W


read_from_tnctohost_fram

;	Only called from i2c Interrupt Handler 

        bcf             PORTA, csbit    ; 0298: 1185

;   fram_bits(0b00000011);		   //this is a read

		movlw           0x03        ; 029D: 3003
        movwf           mem_68      ; 029E: 00E8
        call            fram_bits     ; 029F: 204E

;   fram_bits(hiaddr);			   //send the two byte address
;   fram_bits(loaddr);

        movf            rcvoutaddHi, W   ; 02AF: 0859
        movwf           mem_68      ; 02B0: 00E8
        call            fram_bits     ; 02A8: 204E

		movf            rcvoutaddLo, W   ; 02AF: 0859
        movwf           mem_68      ; 02B0: 00E8
        call            fram_bits     ; 02B1: 204E
          
;   set_tris_a(0b100100);  		   //set I/O to read from FRAM

		movlw           0x06        ; 02B4: 3024
		tris            0x05        ; 02B5: 0065
        
  ;   inbyte = 0;
;   for(bitc=0;bitc<8;bitc++){		//clock in the bits
	
		clrf            mem_56   ; 02B6: 01D6
        clrf            mem_57   ; 02B7: 01D7

bitloop1

; jump here from: 02C3
        movf            mem_57, W   ; 02B8: 0857
        sublw           0x07        ; 02B9: 3C07
        btfss           STATUS, C   ; 02BA: 1C03
        goto            endbitloop1    ; 02BB: 2AC4
        
;         output_high(clock);

        bsf             PORTA, clockbit    ; 02BC: 1405
        
;         if (input(data)) (inbyte++);

        btfsc           PORTA, databit    ; 02BD: 1905
        incf            mem_56, f   ; 02BE: 0AD6
        
;         output_low(clock);

        bcf             PORTA, clockbit    ; 02BF: 1005
    
;         rotate_left(&inbyte,1);

        rlf             mem_56, W   ; 02C0: 0D56
        rlf             mem_56, f   ; 02C1: 0DD6

;    }
        incf            mem_57, f   ; 02C2: 0AD7
        goto            bitloop1   ; 02C3: 2AB8

endbitloop1

;    rotate_right(&inbyte,1);

        rrf             mem_56, W   ; 02C4: 0C56
        rrf             mem_56, f   ; 02C5: 0CD6
        
;    output_high(cs);			      //add done

        bsf             PORTA, csbit    ; 02C6: 1585
        
		movlw           0x02       ; 02B4: 3024
		tris            0x05        ; 02B5: 0065
 
; 	Increment address

       	incf	rcvoutaddLo, f
        btfss	STATUS, Z		;wrapped?
       	goto 	returnval		; no so return

;	Low byte wrapped, so increment hi

		incf	rcvoutaddHi, f
        movf 	rcvoutaddHi, W	; end of buffer?
        sublw	0x8
        btfss	STATUS, Z
       	goto returnval1			; no so return

        clrf	rcvoutaddHi 		; reset hi byte to start of buffer
        
returnval1

		movf	mem_56, W 
		return					; With result in W
		
	
	
	
	
crc_check_and_write_to_host:

	xorwf	TXCRC, f					; include in checksum
	call	CheckKISS					; check for KISS Transparency
	call	write_to_tnctohost_fram

	return
	
CheckKISS:

;	If FEND or ESFC, escape it

	xorlw	0xc0					; I didn;'t think of this
	btfsc	STATUS, Z
	goto	isfend    

	xorlw	0x1b					; Actually checking DB
	btfsc	STATUS, Z
	goto	isfesc

	xorlw	0xdb						; Back to original
	return
		
isfend

	movlw	0xdb
	call	write_to_tnctohost_fram
	retlw	0xdc
		
isfesc

	movlw	0xdb
	call	write_to_tnctohost_fram
	retlw	0xdd


ProcessHostChar:
;
;	Process char from host. May be from asy or i2c handler
    	
	movf	inbyte, W
	sublw	FEND
	btfss	STATUS, Z
	goto	rxnotFEND
	
; Got a FEND. If discarding a frame, this is the ending FEND. Clear discard, and return (ingoring FEND)

	btfss	Discard	; Discarding
	goto	NotDiscarding
		
	bcf		Discard
	return

NotDiscarding:

;	FEND, not discarding. If closing FEND, Pass to TX routine
	
; 	If receiving a frame, write FEND to FRAM and increment frames available	
		
	btfss	xmiddle
	goto	FENDNotInFrame
; 
;	End of frame
;
	bcf		xmiddle		; no longer in frame

	btfss	HOSTCRC		;using CRC?
	goto	NotUsingCRC
	
;	CRC should be zero. If not, discard frame.

	movf	RXCRC, W
	btfsc	STATUS, Z	; Skip of nonzero
	goto GoodFrame
	
; Must also accept 1, as we send FEND as C1 to avoid transparency problem
	
	decf	WREG, W
	btfsc	STATUS, Z	; Skip of nonzero
	goto GoodFrame
	
;	Duff frame

;	reset FRAM pointers

	movf	BeginTXHi, W
	movwf	txinaddHi

	movf	BeginTXLo, W
	movwf	txinaddLo
	
	bsf		SendNACK			; Request repeat
		
	return
 
NotUsingCRC:

;	if not using CRC, then the last byte is data

	movf	LastTXChar, W
	call	write_to_hosttotnc_fram  

GoodFrame
	
	movlw	FEND
	call	write_to_hosttotnc_fram  

	incf	C0xmit, f   ; Frames to TX on radio

	return
		
FENDNotInFrame

;	Opening FEND. Need to check next byte for adddress and possible ctrl bits

	bsf		CheckCtrl
	return

rxnotFEND

	btfsc	xmiddle
	goto	InMiddle		; Cant be discarding if in frame, so short cut

;	Not a FEND. If discarding, disard!

	btfsc	Discard			; Discarding?
	return					; yes, so return

;	Not Fend, Not discarding. Are we looking for a control byte?
				
	btfss	GetCmdParam
	goto	NotCmdParam

;	Got Command Value byte. Process it
		
	bcf		GetCmdParam

;0x00	Set I2c Address
;0x01	TX DELAY
;0x02	Persistence
;0x03	SlotTime
;0x04	TXtail
;0x05	FullDuplex
;0x06	SetHardware (used for Baud Rate
;0x07	Set Power
;0x08	Read Params
;0x09	Reset
;0x0a	Send Carrier
;0x0b	Freq Band
;0x0c	Reserved - ACK MODE
;0x0d	Freq Hi Byte
;0x0e	Freq Lo Byte

;0x0f	Operation Group
;	01	Read Params
;	02	Reset
;	03	Send Carrier

;	Command Value is offset into EEPROM, unless cmd = 0xf
	
	;	0f xx are immediate ommands

	movf	Command, W		; get command
	sublw	15
	btfss	STATUS, Z
	goto	NotImmed
	
	movf	inbyte, W	
	sublw	3				; Send Carrier
	btfss	STATUS, Z
	goto	NotCarrier

	bsf		CarrierFlag		; Set Carrier flag
	goto	CMDEnd
		
NotCarrier:

	decf	WREG, W			
	btfss	STATUS, Z
	goto	NotReboot

	bsf		rebootFlag		; Set reboot flag
	goto	CMDEnd
		
NotReboot:

	decf	WREG, W			
	btfss	STATUS, Z
	goto	CMDEnd

	bsf		sendparms		; Set "Semd Params" flag
	goto	CMDEnd
	
NotImmed:	
	
	movf	Command, W		; get command byte
	call	EEREAD			; get old value - we don't want to weite if not changed
	
	subwf	inbyte, W
	btfsc	STATUS, Z		; skip if unequal	
	goto	CMDEnd			; Not changed, so exit
	
	movf	inbyte, W
	movwf	EEVAL
	
	movf	Command, W		; get command byte
	call	EEWAIT			; ensure any previous write has completed
	call	EEWRITE			; save new value
	
	goto	CMDEnd			; finished
	
NotCmdParam:
		
	btfss	CheckCtrl
	goto	rxNormData
		
;	If another FEND, just ignore. We dont look for FEND after Control Frsme, so often get FEND FEND

	movf	inbyte, W
	sublw	FEND
	btfsc	STATUS, Z		; skip if not FEND
	return
        
; if upper nibble doesnt match out address, set discard and exit

	bcf		CheckCtrl

	movf	inbyte, W
	andlw	0xf0			; Mask Channel
	subwf	OurChannel, W
	btfsc	STATUS, Z		; Zero if our Channel? Skip if not
	goto	GotOurChannel
        
	bsf		Discard			; Set Discarding
	return					; return
        
GotOurChannel:

;	If Data, Write FEND and Control (0) to FRAM and set xmiddle

	movf	inbyte, W
	andlw	0xf				; Mask out channel
	movwf	Command			; save
		
	btfss	STATUS, Z		; if zero, it is a data frame
	goto	NotData

DataFrame

;	Initialise Checksum. Dont include either FEND

;	Note checksum is done on data before encoding, so we shouldn't include any FESC chars in the sum

;	Actually not that simple - we must replace the FESC TFESC and FESC TFEND with FESC and FEND, so need to remember if in
;	ESC'd state

	movf	inbyte, W
	movwf	RXCRC			; Control Byte is in sum
		
; Save Packet start address, in case we need to cancel it

	movf	txinaddHi, W
	movwf	BeginTXHi
	movf	txinaddLo, W
	movwf	BeginTXLo
		       
	movlw	FEND
	call	write_to_hosttotnc_fram  
		
;	We write frame data one byte in arrears, as we dont want to write the checksum byte
     
	movf	Command, W		; Send Control Byte (could be 0 or 0c (ACK)
	movwf	LastTXChar		; Note we include in checksum when received
		
	bsf		xmiddle			; now in frame

	return
		
NotData
		
; May be ACKMode Data frame

	movf	Command, W		; get command
	sublw	ACK				; Ackmode Frame
	btfsc	STATUS, Z		; no, so skip
	goto	DataFrame

;	Must be KISS Param.

	bsf		GetCmdParam	

CMDEnd:

	return
			
rxNormData

;	Make sure we are in a frame. If not, we are getting data without a leading FEND

	btfsc	xmiddle
	goto	InMiddle
		
	return

InMiddle:

;	Just stash away to FRAM - one byte behind

	movf	LastTXChar, W		; Char received before
	call	write_to_hosttotnc_fram  
		
	movf	inbyte, W
	movwf	LastTXChar

	btfss	InFESC
	goto	NotInFESC

	bcf		InFESC
	
;	Last char was FESC, CRC must include the real value (FESC or FEND) not the traslated one

	xorlw	TFESC
	btfss	STATUS,Z	
	goto	rxNotTFESC
	
	movlw	FESC
	xorwf	RXCRC, f			; include in checksum
	return;
	
rxNotTFESC:
	
	xorlw	TFESC				; Restore value
	xorlw	TFEND

	btfss	STATUS,Z	
	goto	rxNotTFEND
	
	movlw	FEND
	xorwf	RXCRC, f			; include in checksum
	return;
	
rxNotTFEND:

;	Either error or D700 mode escaped 'C'. In either case, include char

	xorlw	TFEND
	xorwf	RXCRC, f			; include in checksum
	return;
	
NotInFESC:

	xorlw	FESC				; Was it FESC?
	btfss	STATUS,Z			; Yes, skip next
	goto	notFESC

	bsf		InFESC				; Need to check next char
	return						; dont include FESC

notFESC:

	xorlw	FESC				; No, so restore value
	xorwf	RXCRC, f			; include in checksum
      
	return

;	i2c Code

;---------------------------------------------------------------------
SSP_Handler

;	We just use i2c_smbus_write_byte and i2c_smbus_read_byte for single byte transfers.
;
;	The Master polls by issuing a read
;
;	Response is either data from a KISS frame, one char at a time, ending with FEND, or 
;	an ACK response (0E). If the master gets anything other than 0E as the first byte,
;	it carries on reading until it sees a FEND
;
;	Framees are sent to the TNC a byte at a time, starting with FEND, then the control byte, and ending with FEND
;
;
;	Temp is in shared RAM


;	Entered in bank 0

	bcf 	PIR1,SSP1IF			; Clear interrupt
		
	MYBANKSEL SSPSTAT
	
	btfss	SSPCON1, SSPOV		; Overflow?
	goto no_overflow
	
	movf	SSPCON1, W

	bcf		SSPCON1, SSPOV		;
	
no_overflow:
	
	movf SSPSTAT,W ; Get the value of SSPSTAT

	andlw 0x2d ; b� 00101101� ; Mask out unimportant bits in SSPSTAT.
	movwf Temp ; for comparision checking.
		
	MYBANKSEL SSPSTAT
		
State1: ; Write operation, last byte was an address, buffer is full.

	movlw 0x09	; b�00001001� ;
	xorwf Temp,W ;
	btfss STATUS,Z ; Are we in State1?
	goto State2 ; No, check for next state.....

;	This seems to be giving the i2c Address (0x10)

	movf SSPBUF,W ; Get the byte and put in WREG
	bsf SSPCON,CKP ; Release the clock.

	retfie

State2: ; Write operation, last byte was data, buffer is full.

	movlw 0x29	; b�00101001� ;
	xorwf Temp,W
	btfss STATUS,Z ; Are we in State2?
	goto State3 ; No, check for next state.....
	
;	This is the actual write

	movf SSPBUF,W ; Get the byte and put in WREG
	
    MYBANKSEL	STATUS
		       
    movwf	inbyte  
    call	ProcessHostChar

	MYBANKSEL SSPCON
	bsf SSPCON,CKP 			; Release the clock.
	
	retfie
 

State3: ; Read operation, last byte was an address, buffer is empty.

	movlw 	0x0c		; b�00001100� ;
	xorwf 	Temp,W
	btfss 	STATUS,Z 	; Are we in State3?
	goto 	State4 		; No, check for next state.....

	movf 	SSPBUF,W ; Get the byte and put in WREG

	movf	Temp, W
	call 	WriteI2C 	; Write the byte to SSPBUF

	retfie

State4: ; Read operation, last byte was address, buffer is full.

	movlw 	0x0d		; b�00001101� ;
	xorwf 	Temp,W
	btfss 	STATUS,Z 	; Are we in State3?
	goto 	State4a 	; No, check for next state.....

	movf 	SSPBUF,W 	; Get the byte and put in WREG
	
	MYBANKSEL	STATUS
		
;	If NACK needed, send it, else if anything to send, send it.
;   Otherwise return a POLL

	btfss	SendNACK
	goto 	noNACK
	
	bcf		SendNACK
	
	movlw	NACK
	MYBANKSEL SSPSTAT
	call 	WriteI2C 	; Write the byte to SSPBUF

	retfie

noNACK:

	movf	receivedpackets, f
	btfsc	STATUS, Z	; skip if something to send
	goto SendPOLL
		
	call	read_from_tnctohost_fram
	MYBANKSEL SSPSTAT		
	call 	WriteI2C 	; Write the byte to SSPBUF
	MYBANKSEL STATUS
       
	sublw	FEND
	btfss	STATUS, Z
	retfie				; normal char
		
;	Got FEND

	btfss	rmiddle
	goto	NowInFrame

;	Was in frame, so now at end

	bcf		rmiddle
	decf	receivedpackets, f
	retfie

NowInFrame:

	bsf		rmiddle		; Now in frame
	retfie

SendPOLL:

	movlw	POLL
	MYBANKSEL SSPSTAT
	call 	WriteI2C 	; Write the byte to SSPBUF

	retfie

State4a: ; Read operation, last byte was data, buffer is empty.

	movlw 0x2c ; b�00101100� ;
	xorwf Temp,W
	btfss STATUS,Z ; Are we in State4?
	goto State5 ; No, check for next state....

	movlw	0xaa
	movf	Temp, W
	call 	WriteI2C ; Write the byte to SSPBUF
	retfie

State5:

	movlw	0x28	; b�00101000� 
	; A NACK was received when transmitting data back from the master. Slave logic is reset in this case.
	; R_W = 0, D_A = 1
	
	xorwf Temp,W ; 
	btfss STATUS,Z ; 
	goto I2CErr ; and BF = 0

	movf SSPBUF,W ; Get the byte and put in WREG

	bsf SSPCON,CKP ; Release the clock.
	retfie ; If we aren�t in State5, then something is; wrong.
	
I2CErr:

;	call 	WriteI2C ; Write the byte to SSPBUF
;	incf 	Rindex,F ; Increment the buffer index.

	movf SSPBUF,W ; Get the byte and put in WREG
	
	bsf SSPCON,CKP ; Release the clock.
	retfie

;---------------------------------------------------------------------
; WriteI2C
;---------------------------------------------------------------------
WriteI2C

	btfsc SSPSTAT,BF ; Is the buffer full?
	goto WriteI2C ; Yes, keep waiting.

DoI2CWrite
	bcf SSPCON,WCOL; Clear the WCOL flag.
	movwf SSPBUF ; Write the byte in WREG
	btfsc SSPCON,WCOL; Was there a write collision?
	goto DoI2CWrite
	bsf SSPCON,CKP ; Release the clock.
	return
	

;------------- symbol definitions ------------------

mem_00    equ   0x00
;mem_20    equ   0x20
;STATUS_TEMP    equ   0x21
;FSR0_TEMP    equ   0x22
mem_23    equ   0x23
mem_24    equ   0x24
mem_25    equ   0x25
mem_26    equ   0x26
mem_27    equ   0x27
;PCLATH_TEMP    equ   0x28
mem_29    equ   0x29
;mem_2a    equ   0x2A
minus1    equ   0x2B
minus2    equ   0x2C
rcvbyte    equ   0x2D
bitcount    equ   0x2E
boolflags    equ   0x2F
ones    equ   0x30
crc_lo    equ   0x31
crc_hi    equ   0x32
count    equ   0x33
receivedpackets    equ   0x34
C0xmit    equ   0x35
rcvinaddLo    equ   0x36
rcvinaddHi    equ   0x37
rcvoutaddLo    equ   0x38
rcvoutaddHi    equ   0x39
beginLo    equ   0x3A			; Start Addr of current packet
beginHi    equ   0x3B
txinaddLo    equ   0x3C
txinaddHi    equ   0x3D
txoutaddLo    equ   0x3E
txoutaddHi    equ   0x3F
xcrchi    equ   0x40
xcrclo    equ   0x41
stuff    equ   0x42
xmitlatch    equ   0x43
persist    equ   0x44
slottime    equ   0x45
slotcount    equ   0x46

AcksToSendCount	equ	0x47		; Number of ACKMODE reponses to send when we have finished txing
LastTXChar    equ   0x48		; We dont write chars from host to FRAM till the mext arrives, as last is CRC

mem_49    equ   0x49
mem_4a    equ   0x4A
;inbyt    equ   0x4B
work1    equ   0x4C
mem_4d    equ   0x4D
txdelay    equ   0x4E
txflags    equ   0x4F
txbyte    equ   0x50
mem_51    equ   0x51
mem_52    equ   0x52

mem_53    equ   0x53

i2cwork		equ	0x54	
;inbyte    equ   0x55

mem_56    equ   0x56
mem_57    equ   0x57
mem_58    equ   0x58
mem_59    equ   0x59
kissflags equ 0x5A

AckByte2	equ	0x5b
TXCRC		equ	0x5c	; Checksum for TNC-PC
RXCRC		equ	0x5d	; Checksum for PC-TNC
Command		equ	0x5e
AckByte1	equ	0x5f

; mem_5f    equ   0x5F
rbit    equ   0x60
mem_61    equ   0x61
mem_62    equ   0x62
mem_63    equ   0x63
mem_64    equ   0x64
mem_65    equ   0x65
mem_66    equ   0x66
mem_67    equ   0x67
mem_68    equ   0x68
mem_69    equ   0x69
mem_6a    equ   0x6A

BeginTXLo	equ	0x6C	; Saved addr of packet from host
BeginTXHi	equ	0x6D	; Saved addr of packet from host

bpqflags	equ 0x6E
OurChannel	equ	0x6f

	cblock 0x70			; Shared across all banks
	
SaveRXStat				; Used in getc. In shared space
Temp					; Used in I2C Interrupt routines
FrameBits
delay_ms_counter
inbyte					; char from i2c or async

mem_77
mem_78
mem_79
mem_7a
mem_7b

EEVAL					; Value to write to EEPROM

	endc

	end


